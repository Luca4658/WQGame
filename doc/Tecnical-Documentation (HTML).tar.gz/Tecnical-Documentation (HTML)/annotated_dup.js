var annotated_dup =
[
    [ "client", "d7/d1c/namespaceclient.html", "d7/d1c/namespaceclient" ],
    [ "server", "d9/db1/namespaceserver.html", "d9/db1/namespaceserver" ]
];