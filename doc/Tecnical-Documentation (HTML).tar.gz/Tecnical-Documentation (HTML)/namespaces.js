var namespaces =
[
    [ "client", "d7/d1c/namespaceclient.html", null ],
    [ "server", "d9/db1/namespaceserver.html", null ]
];