var classserver_1_1_users =
[
    [ "Users", "d1/df8/classserver_1_1_users.html#a572d0f1cdfa330e1198d2484f4809032", null ],
    [ "deleteUser", "d1/df8/classserver_1_1_users.html#a01840ab4a8ff052e96d1a2db4829cc3c", null ],
    [ "getNusers", "d1/df8/classserver_1_1_users.html#a0fa321986e6559cfd8e1f1fdac2db447", null ],
    [ "getRanking", "d1/df8/classserver_1_1_users.html#a95b6f69bdb653a76047bf64cc20b1d06", null ],
    [ "getUser", "d1/df8/classserver_1_1_users.html#a9f5e0c7f293152ae28f1028d4bc6c2df", null ],
    [ "init", "d1/df8/classserver_1_1_users.html#adb6c396c788427da87a7ee3ecef3fb3e", null ],
    [ "insertUser", "d1/df8/classserver_1_1_users.html#a6225be675bdabd3ac16451a87f7cbc55", null ],
    [ "searchUser", "d1/df8/classserver_1_1_users.html#a8a98cac569a4672c78b48ca910635468", null ],
    [ "shutdown", "d1/df8/classserver_1_1_users.html#a8dcd4c83711d7c4e6603fc294ec566c0", null ],
    [ "updateUser", "d1/df8/classserver_1_1_users.html#a2ecb399f7626fde42cd4ac1e1244144c", null ],
    [ "writeONfile", "d1/df8/classserver_1_1_users.html#a122367905104412b396d6767f537e479", null ],
    [ "__dbFile", "d1/df8/classserver_1_1_users.html#a64a7ac52059d739b0c67ff5bd0f42454", null ],
    [ "__dbUser", "d1/df8/classserver_1_1_users.html#a37ffecd4d1ba289c66c23efdb35f49e3", null ],
    [ "__parser", "d1/df8/classserver_1_1_users.html#a70e65f03c3293073b4dd4c48c9e190e7", null ],
    [ "__PATHDBU", "d1/df8/classserver_1_1_users.html#a25937f7f3801c4608fc52771e61138bb", null ],
    [ "__size", "d1/df8/classserver_1_1_users.html#a36a23f0b50516f08070ec49affa8f29f", null ],
    [ "__users", "d1/df8/classserver_1_1_users.html#a7b9717dd016485f5c48ce1e152bfe322", null ]
];