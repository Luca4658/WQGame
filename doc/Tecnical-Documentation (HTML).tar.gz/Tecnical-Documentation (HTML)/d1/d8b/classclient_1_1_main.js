var classclient_1_1_main =
[
    [ "connect", "d1/d8b/classclient_1_1_main.html#a80b1c7132120b55ece737c2146d6fc6d", null ],
    [ "getMyPort", "d1/d8b/classclient_1_1_main.html#a365590d7a6c38489e28275acc88031f7", null ],
    [ "main", "d1/d8b/classclient_1_1_main.html#a757d493b68aa66d3d3c2e71a1c6e4c0e", null ],
    [ "recv", "d1/d8b/classclient_1_1_main.html#a181f25f323c7e685dd1d9433d1099d9e", null ],
    [ "send", "d1/d8b/classclient_1_1_main.html#a83c701afa35d7f20e269b7e0a834917b", null ],
    [ "inBuff", "d1/d8b/classclient_1_1_main.html#ae18c54e1db6be43dbe40b469fd3f31dd", null ],
    [ "outBuff", "d1/d8b/classclient_1_1_main.html#a8db165e08cef8e12ee7e6be33000f77a", null ],
    [ "parser", "d1/d8b/classclient_1_1_main.html#aa3f1d074e3916111a2f5ea5acdfc6cf4", null ],
    [ "reg", "d1/d8b/classclient_1_1_main.html#a26451f962381a854064e57635572a14f", null ],
    [ "socket", "d1/d8b/classclient_1_1_main.html#a40025b291a101faaace560148a0ba023", null ],
    [ "stub", "d1/d8b/classclient_1_1_main.html#a7017cf9366f11da16c0859ec2f192f77", null ]
];