var classclient_1_1com_u_d_p =
[
    [ "comUDP", "db/de5/classclient_1_1com_u_d_p.html#a47df4ae16b95ebb5149dba5a10c69267", null ],
    [ "run", "db/de5/classclient_1_1com_u_d_p.html#abe54e17d09c0ae1b8d54567473c0a092", null ],
    [ "send", "db/de5/classclient_1_1com_u_d_p.html#ab4b1bb8a28c1ca024a71fb4246a8f71e", null ],
    [ "mainUI", "db/de5/classclient_1_1com_u_d_p.html#a9fa5a904612a75a9e89f6dfd2f592f71", null ],
    [ "myport", "db/de5/classclient_1_1com_u_d_p.html#ace827e622750d294765e9f1ab82c8198", null ],
    [ "packToRecv", "db/de5/classclient_1_1com_u_d_p.html#a354948ec79de7bc707d629c8d13428bf", null ],
    [ "packToSend", "db/de5/classclient_1_1com_u_d_p.html#af6591b3f782f3fb55aa462092fa5faad", null ],
    [ "sock", "db/de5/classclient_1_1com_u_d_p.html#a7a18407cfe05d3942c8f4e6cbd302756", null ]
];