var classclient_1_1_my_action_listener =
[
    [ "challenge", "d0/d4f/classclient_1_1_my_action_listener.html#abdcc1e3a1acf7abd11f0a28d4ea49325", null ],
    [ "getRank", "d0/d4f/classclient_1_1_my_action_listener.html#a781ac4bce0ba1e6b3a3f95cd70a63cb1", null ],
    [ "goUpdate", "d0/d4f/classclient_1_1_my_action_listener.html#a2b7db60a659b79e769925718390ebd89", null ],
    [ "logout", "d0/d4f/classclient_1_1_my_action_listener.html#a38c6d625507503c2d38d1adf06716ab5", null ],
    [ "removeFriend", "d0/d4f/classclient_1_1_my_action_listener.html#a76c974de2594d882e917854e89631f4f", null ],
    [ "removeUser", "d0/d4f/classclient_1_1_my_action_listener.html#a73567e99426d258ac8899fb7d6de8bd8", null ],
    [ "setAddFriend", "d0/d4f/classclient_1_1_my_action_listener.html#a7ff3bc76130c32f8ae5daeded0fff36b", null ],
    [ "setBack1", "d0/d4f/classclient_1_1_my_action_listener.html#a703ae633b82275f243e1e24c90bbd488", null ],
    [ "setBack2", "d0/d4f/classclient_1_1_my_action_listener.html#afd96d983f593c393b961ea4f920ad377", null ],
    [ "setBack3", "d0/d4f/classclient_1_1_my_action_listener.html#a86a9069e7e999221b500f6b9725a0ace", null ],
    [ "setGoLogin", "d0/d4f/classclient_1_1_my_action_listener.html#a8291ccd44507abb79c8c369cc75c0863", null ],
    [ "setGoReg", "d0/d4f/classclient_1_1_my_action_listener.html#afc2e16c712210ba51be082340b2a3763", null ],
    [ "setSignin", "d0/d4f/classclient_1_1_my_action_listener.html#a33ee0becd34aa2f4dfd54580ed8ce113", null ],
    [ "setSignup", "d0/d4f/classclient_1_1_my_action_listener.html#a591cd95d4427bfbb6b14f48f46616436", null ],
    [ "update", "d0/d4f/classclient_1_1_my_action_listener.html#aebc81e6ce9ec96787c41dea779d12f7f", null ],
    [ "updateFriend", "d0/d4f/classclient_1_1_my_action_listener.html#ab2d4731751d5e5d78d95071bdefb1aed", null ]
];