var classserver_1_1_main =
[
    [ "getDictionary", "dc/d3e/classserver_1_1_main.html#a24a35c530539535dcd7b080b9fff02d2", null ],
    [ "getUniPort", "dc/d3e/classserver_1_1_main.html#afde6ae3dc99117f3b0526062d2666308", null ],
    [ "getWinner", "dc/d3e/classserver_1_1_main.html#ad7d5ab1bc4b50a4f1ac455e8a62253b3", null ],
    [ "getWords", "dc/d3e/classserver_1_1_main.html#a59d2f4a3cbb1d408813f6a6146903d08", null ],
    [ "logger", "dc/d3e/classserver_1_1_main.html#aa04bbcc777a30a4c4e11869041fd627d", null ],
    [ "main", "dc/d3e/classserver_1_1_main.html#a485ff13a0726374c73106c6c84570313", null ],
    [ "setWords", "dc/d3e/classserver_1_1_main.html#ac1f83e926383d1dbd5390393a1f0cd53", null ],
    [ "Dictionary", "dc/d3e/classserver_1_1_main.html#ab9bca795443453fde1d6c4db67c0392b", null ],
    [ "FDB", "dc/d3e/classserver_1_1_main.html#a53c7daf0fa2403230dd640ec545deeda", null ],
    [ "LISTENER", "dc/d3e/classserver_1_1_main.html#a32ccbf315aaa70b151abd4df9c24c197", null ],
    [ "logfile", "dc/d3e/classserver_1_1_main.html#a7ea4ca4d50a04ca611a2694539a8a0df", null ],
    [ "parser", "dc/d3e/classserver_1_1_main.html#abcd632cee8f80b7f111541da444fcbe3", null ],
    [ "Tpool", "dc/d3e/classserver_1_1_main.html#a7af1317336b6c856a6b872d21530524c", null ],
    [ "UDB", "dc/d3e/classserver_1_1_main.html#a6e94f0664927bc481b5676a74efe8582", null ],
    [ "updater", "dc/d3e/classserver_1_1_main.html#aebca1fbf1ae27897da88e3d4e17478f3", null ]
];