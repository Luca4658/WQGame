var classserver_1_1_client_tasks =
[
    [ "ClientTasks", "dc/de3/classserver_1_1_client_tasks.html#a5c4bac75a8461e6d596f62f3eb0bffa9", null ],
    [ "checkFStatus", "dc/de3/classserver_1_1_client_tasks.html#a8c1ab52d10eedfa637f0db443da00b86", null ],
    [ "Game", "dc/de3/classserver_1_1_client_tasks.html#af1c4cdab9b547d70b9d2cffa5a92f646", null ],
    [ "personalRank", "dc/de3/classserver_1_1_client_tasks.html#ad9c6c6b6d1d1b390f4abfc1dbca6552d", null ],
    [ "recv", "dc/de3/classserver_1_1_client_tasks.html#a19d4b9b92c2492dbb21d184f638f572a", null ],
    [ "run", "dc/de3/classserver_1_1_client_tasks.html#adc09af1b52839bd6ecc879ef3864a73b", null ],
    [ "send", "dc/de3/classserver_1_1_client_tasks.html#ab6cef5da33075b43d99e6d01a5d2bbf2", null ],
    [ "sendRequest", "dc/de3/classserver_1_1_client_tasks.html#ad3902dac95697fc1c319e38417673b51", null ],
    [ "__cSocket", "dc/de3/classserver_1_1_client_tasks.html#aa8a1740261b708ba845137182f326b84", null ],
    [ "__end", "dc/de3/classserver_1_1_client_tasks.html#ae1370bb05ba40365bee9c0b7e299cf99", null ],
    [ "__fdb", "dc/de3/classserver_1_1_client_tasks.html#a3e0bdc7ab5a21d88375ba863c82667c9", null ],
    [ "__inBuff", "dc/de3/classserver_1_1_client_tasks.html#aed11170944c93679ab57ff08fe136265", null ],
    [ "__me", "dc/de3/classserver_1_1_client_tasks.html#a26ae9c37182121d9a82aff2efc25fba0", null ],
    [ "__outBuff", "dc/de3/classserver_1_1_client_tasks.html#ab8b825eacf5366ee4fa232023110c7ef", null ],
    [ "__udb", "dc/de3/classserver_1_1_client_tasks.html#a55e90977dbb42abfce9e1f13edcfa85c", null ]
];