var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "client", "dir_6908ff505388a07996d238c763adbdab.html", "dir_6908ff505388a07996d238c763adbdab" ],
    [ "server", "dir_075bb3ff235063c77951cd176d15a741.html", "dir_075bb3ff235063c77951cd176d15a741" ]
];