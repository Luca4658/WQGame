var enumclient_1_1_client_m_s_g =
[
    [ "ACCEPTEDCH", "d4/de8/enumclient_1_1_client_m_s_g.html#a0feffd0713feb5cc228a985631568e81", null ],
    [ "ADDFRIEND", "d4/de8/enumclient_1_1_client_m_s_g.html#a0f0194eafb7e05f4f5d2afcd43e53c5d", null ],
    [ "GETFRIENDS", "d4/de8/enumclient_1_1_client_m_s_g.html#afd116d21e19b5dbc20bc1919f516c489", null ],
    [ "GETNFRIENDS", "d4/de8/enumclient_1_1_client_m_s_g.html#af83efc40f2e06ebb5c72c73a4b8ecd73", null ],
    [ "GETPOINTS", "d4/de8/enumclient_1_1_client_m_s_g.html#a9f360ed97cad29bd5a10718ec0f1ad68", null ],
    [ "GETRANK", "d4/de8/enumclient_1_1_client_m_s_g.html#ab4a962ce4832599e5dedc1e537507b63", null ],
    [ "LOGIN", "d4/de8/enumclient_1_1_client_m_s_g.html#a0ab791b0428034800bd8547fa8c75e16", null ],
    [ "LOGOUT", "d4/de8/enumclient_1_1_client_m_s_g.html#a5ca438abbc7ff91fde2caadebfa5876f", null ],
    [ "RMUSER", "d4/de8/enumclient_1_1_client_m_s_g.html#aa711761f4c8260e3616695e7414af8cc", null ],
    [ "STARTCH", "d4/de8/enumclient_1_1_client_m_s_g.html#ab0d5c868005d08cbd7ab92829b739b98", null ],
    [ "UPDATEINFO", "d4/de8/enumclient_1_1_client_m_s_g.html#a533819726bdc7cde3e7d27581c56b4fa", null ]
];