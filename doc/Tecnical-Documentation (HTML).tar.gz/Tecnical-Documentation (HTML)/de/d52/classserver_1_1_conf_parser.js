var classserver_1_1_conf_parser =
[
    [ "ConfParser", "de/d52/classserver_1_1_conf_parser.html#a042562aba9a808ceab6b97e291b8a1d1", null ],
    [ "getCorrectPoints", "de/d52/classserver_1_1_conf_parser.html#acb9fa34456445fa474e3db44b009b8cd", null ],
    [ "getDictionaryPath", "de/d52/classserver_1_1_conf_parser.html#abe81870f760fde17f95e06e94d261045", null ],
    [ "getExtraPoints", "de/d52/classserver_1_1_conf_parser.html#a431fce55b9b91e84653bd81ae345960b", null ],
    [ "getFriendPath", "de/d52/classserver_1_1_conf_parser.html#a186ea46fd95b71a49deb31039180f099", null ],
    [ "getListnerPort", "de/d52/classserver_1_1_conf_parser.html#a3c1c1aaf106fcdf01ff6edb21f1b1490", null ],
    [ "getLogfilePath", "de/d52/classserver_1_1_conf_parser.html#a6b0065ece3f3be44b59964375d9c9aaf", null ],
    [ "getNWords", "de/d52/classserver_1_1_conf_parser.html#a203294f99a888167a7fd844671b22456", null ],
    [ "getRMIPort", "de/d52/classserver_1_1_conf_parser.html#a0e195ab939e98e3354faf870c2b80237", null ],
    [ "getTimeoutGame", "de/d52/classserver_1_1_conf_parser.html#afeada98178582848dd9711bf02a8b0de", null ],
    [ "getTimeoutReply", "de/d52/classserver_1_1_conf_parser.html#a473f57ba1ef749d3e0f9de5e57eb6dc4", null ],
    [ "getTimeUpdater", "de/d52/classserver_1_1_conf_parser.html#aca12fb087afe47554c2fe0fea764961d", null ],
    [ "getUsersPath", "de/d52/classserver_1_1_conf_parser.html#a8f6ba5ffe3be6644c35174a166fc7e48", null ],
    [ "getWrongPoints", "de/d52/classserver_1_1_conf_parser.html#abac2780c022fd3e79765cae1760a25b9", null ],
    [ "__conf", "de/d52/classserver_1_1_conf_parser.html#afc55e24fa43da939579c5f5e850ad968", null ]
];