var classclient_1_1_tasks =
[
    [ "addFriend", "d2/da3/classclient_1_1_tasks.html#ac513d70d6f2e1f64680c9a8e28c9c1f8", null ],
    [ "friendlist", "d2/da3/classclient_1_1_tasks.html#a05d2dec9bb6a69f23350cc694c5d1263", null ],
    [ "getPoints", "d2/da3/classclient_1_1_tasks.html#a6f7a977799a51e4305640220e7aa3142", null ],
    [ "getRank", "d2/da3/classclient_1_1_tasks.html#ac74effd089d0eb698bb382ce3eb48fcf", null ],
    [ "login", "d2/da3/classclient_1_1_tasks.html#ad5e2b9caf6ce28274cdeb7264dee9988", null ],
    [ "logout", "d2/da3/classclient_1_1_tasks.html#ac564b1941af2b21714e6ee0147bb902e", null ],
    [ "reg", "d2/da3/classclient_1_1_tasks.html#a660bf3406c24313233397634059ef5d3", null ],
    [ "rmFriend", "d2/da3/classclient_1_1_tasks.html#af0a11c3f6ddf8b86f5464ce1d26af0e5", null ],
    [ "rmUser", "d2/da3/classclient_1_1_tasks.html#a1d765f8912493d07b05c3ba32ba10149", null ],
    [ "updateProfile", "d2/da3/classclient_1_1_tasks.html#aa8a00652e75ce560eda11a9709e3a880", null ]
];