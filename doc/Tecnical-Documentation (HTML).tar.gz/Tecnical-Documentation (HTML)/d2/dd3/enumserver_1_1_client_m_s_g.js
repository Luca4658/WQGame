var enumserver_1_1_client_m_s_g =
[
    [ "ACCEPTEDCH", "d2/dd3/enumserver_1_1_client_m_s_g.html#ac84c314fe542f18af9942c85206c4cbe", null ],
    [ "ADDFRIEND", "d2/dd3/enumserver_1_1_client_m_s_g.html#a5591cc3cd42450295e41ad5af9d0b93e", null ],
    [ "GETFRIENDS", "d2/dd3/enumserver_1_1_client_m_s_g.html#ae5b61e17232e8585edb1c954d0b7f9f1", null ],
    [ "GETNFRIENDS", "d2/dd3/enumserver_1_1_client_m_s_g.html#a7500951956d47cdbc6c5c8c8b3b44d2c", null ],
    [ "GETPOINTS", "d2/dd3/enumserver_1_1_client_m_s_g.html#a129e950cca8bbebc17693464ac2a5e9c", null ],
    [ "GETRANK", "d2/dd3/enumserver_1_1_client_m_s_g.html#ab2efccfedac7ba8657e3cd680aef8caf", null ],
    [ "LOGIN", "d2/dd3/enumserver_1_1_client_m_s_g.html#a46741a69763321929ed2ec70dfa6ba94", null ],
    [ "LOGOUT", "d2/dd3/enumserver_1_1_client_m_s_g.html#af3cb7d68c0ce335e815e24be618e6eed", null ],
    [ "RMUSER", "d2/dd3/enumserver_1_1_client_m_s_g.html#a0cbdc75ac927b51ec51c068692ccd986", null ],
    [ "STARTCH", "d2/dd3/enumserver_1_1_client_m_s_g.html#a9f5441ab16a29d8b02a8810a9beb436e", null ],
    [ "UPDATEINFO", "d2/dd3/enumserver_1_1_client_m_s_g.html#ab83bbbccec0d817ced348b0b19808019", null ]
];