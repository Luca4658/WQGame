var classserver_1_1_friendships =
[
    [ "Friendships", "da/d4c/classserver_1_1_friendships.html#ad22ee973f1b7adac4323f21f298bfba1", null ],
    [ "addFriend", "da/d4c/classserver_1_1_friendships.html#a066ee057a5d878d61cfa3fc42862a1f1", null ],
    [ "getFriends", "da/d4c/classserver_1_1_friendships.html#af4cc5769b42359e959a2b606f0420aaa", null ],
    [ "getNFriends", "da/d4c/classserver_1_1_friendships.html#a85c34570cf34c3beee547f36571839e3", null ],
    [ "init", "da/d4c/classserver_1_1_friendships.html#aafef6cb5e740feb076ab6d6aaeac8b3c", null ],
    [ "newUser", "da/d4c/classserver_1_1_friendships.html#a2979b728d173bc65a394412ff1a01e63", null ],
    [ "removeFriend", "da/d4c/classserver_1_1_friendships.html#ad35902a5266885e01ede1551eff6b800", null ],
    [ "removeUser", "da/d4c/classserver_1_1_friendships.html#a6d857bb2f9f13d825f1fd9b93bbf7b2d", null ],
    [ "searchFriend", "da/d4c/classserver_1_1_friendships.html#ae2ac3113e842929cf5bedb6441cdac65", null ],
    [ "writeONfile", "da/d4c/classserver_1_1_friendships.html#a13369b10121156b3f30fe6358e3f636a", null ],
    [ "__dbFriend", "da/d4c/classserver_1_1_friendships.html#a3d36a8669b3eb2646461c692860cf5ee", null ],
    [ "__friends", "da/d4c/classserver_1_1_friendships.html#ad061cfe1ca5c08841a85964dd3ad8313", null ],
    [ "__PATHDBF", "da/d4c/classserver_1_1_friendships.html#a4ea5e7e7dbfb5b22b8f72387a3751015", null ]
];