var hierarchy =
[
    [ "client.ACK", "d7/d4f/enumclient_1_1_a_c_k.html", null ],
    [ "server.ACK", "d1/d6c/enumserver_1_1_a_c_k.html", null ],
    [ "client.ClientMSG", "d4/de8/enumclient_1_1_client_m_s_g.html", null ],
    [ "server.ClientMSG", "d2/dd3/enumserver_1_1_client_m_s_g.html", null ],
    [ "client.ConfParser", "de/d8f/classclient_1_1_conf_parser.html", null ],
    [ "server.ConfParser", "de/d52/classserver_1_1_conf_parser.html", null ],
    [ "server.Friendships", "da/d4c/classserver_1_1_friendships.html", null ],
    [ "JFrame", null, [
      [ "client.CGUI", "dc/da4/classclient_1_1_c_g_u_i.html", null ]
    ] ],
    [ "server.Main", "dc/d3e/classserver_1_1_main.html", null ],
    [ "client.Main", "d1/d8b/classclient_1_1_main.html", null ],
    [ "client.MyActionListener", "d0/d4f/classclient_1_1_my_action_listener.html", null ],
    [ "RemoteServer", null, [
      [ "server.RegRMImplementation", "d5/d8f/classserver_1_1_reg_r_m_implementation.html", null ]
    ] ],
    [ "Runnable", null, [
      [ "client.comUDP", "db/de5/classclient_1_1com_u_d_p.html", null ],
      [ "client.Game", "dd/dff/classclient_1_1_game.html", null ],
      [ "server.Challenge", "d7/dc9/classserver_1_1_challenge.html", null ],
      [ "server.ClientTasks", "dc/de3/classserver_1_1_client_tasks.html", null ],
      [ "server.DBsWriter", "da/d4b/classserver_1_1_d_bs_writer.html", null ]
    ] ],
    [ "client.Tasks", "d2/da3/classclient_1_1_tasks.html", null ],
    [ "Remote", null, [
      [ "server.RegRMInterface", "d8/d6e/interfaceserver_1_1_reg_r_m_interface.html", [
        [ "server.RegRMImplementation", "d5/d8f/classserver_1_1_reg_r_m_implementation.html", null ]
      ] ]
    ] ],
    [ "Serializable", null, [
      [ "server.User", "dd/df2/classserver_1_1_user.html", null ],
      [ "server.Users", "d1/df8/classserver_1_1_users.html", null ]
    ] ]
];